# Briks — site officiel

Site vitrine + documentation + playground du projet Briks.

## Pages
- `index.html` — accueil et présentation
- `docs.html` — documentation officielle
- `playground.html` — éditeur Briks interactif dans le navigateur
- `downloads/Briks_Studio_3.1_Web.zip` — téléchargement de Briks Studio 3.1
- `briks-web.js` — moteur Briks Web utilisé par le playground

Tout fonctionne en local. Ouvre simplement `index.html`.
